<div class="cover" style="page-break-after:always;font-family:方正公文仿宋;width:100%;height:100%;border:none;margin: 0 auto;text-align:center;">
    <div style="width:60%;margin: 0 auto;height:0;padding-bottom:10%;">
        </br>
        <img src="D:\大三冲刺\计算机网络\实验\校名.png" alt="校名" style="width:100%;"/>
    </div>
    </br></br></br></br></br>
    <div style="width:60%;margin: 0 auto;height:0;padding-bottom:40%;">
        <img src="D:\大三冲刺\计算机网络\实验\校徽.png" alt="校徽" style="width:100%;"/>
	</div>
    </br></br></br></br></br></br></br></br>
    <span style="font-family:华文黑体Bold;text-align:center;font-size:20pt;margin: 10pt auto;line-height:30pt;">第5次实验：ICMP</span>
    <p style="text-align:center;font-size:14pt;margin: 0 auto">实验报告 </p>
    </br>
    </br>
    <table style="border:none;text-align:center;width:72%;font-family:仿宋;font-size:14px; margin: 0 auto;">
    <tbody style="font-family:方正公文仿宋;font-size:12pt;">
    	<tr style="font-weight:normal;"> 
    		<td style="width:20%;text-align:right;">题　　目</td>
    		<td style="width:2%">：</td> 
    		<td style="width:40%;font-weight:normal;border-bottom: 1px solid;text-align:center;font-family:华文仿宋"> ICMP</td>     </tr><tr style="font-weight:normal;"> 
		<td style="width:20%;text-align:right;">授课教师</td>
		<td style="width:2%">：</td> 
		<td style="width:40%;font-weight:normal;border-bottom: 1px solid;text-align:center;font-family:华文仿宋">肖明忠 </td>     </tr>
	<tr style="font-weight:normal;"> 
		<td style="width:20%;text-align:right;">姓　　名</td>
		<td style="width:2%">：</td> 
		<td style="width:40%;font-weight:normal;border-bottom: 1px solid;text-align:center;font-family:华文仿宋"> 段欣然</td>     </tr>
	<tr style="font-weight:normal;"> 
		<td style="width:20%;text-align:right;">日　　期</td>
		<td style="width:2%">：</td> 
		<td style="width:40%;font-weight:normal;border-bottom: 1px solid;text-align:center;font-family:华文仿宋">2023.5.1</td>     </tr>
</tbody>              
</table></div>







<!-- 注释语句：导出PDF时会在这里分页 -->



# 

<center><div style='height:2mm;'></div><div style="font-family:华文楷体;font-size:14pt;">段欣然，202011081033</div></center>
<center><span style="font-family:华文楷体;font-size:9pt;line-height:9mm">北京师范大学 人工智能学院</span>
</center>
<div>
<div style="width:52px;float:left; font-family:方正公文黑体;">目的：</div> 
<div style="overflow:hidden; font-family:华文楷体;">要看ICMP（互联网控制信息协议）是如何使用的。ICMP是IP的一个配套协议，通过处理各种错误和测试情况，帮助IP执行其功能。通过处理各种错误和测试情况来帮助IP执行其功能。它在第5.6.4节中有介绍。文中有涉及。在做这个实验之前，先复习一下这一部分。
</div>
<div>
<div style="width:52px;float:left; font-family:方正公文黑体;">环境：</div> 
<div style="overflow:hidden; font-family:华文楷体;">WireShark；tracert；ping </div>
</div>




<hr>													
<center><b><font size=6>实验报告正文</font></b></center>



# 实验过程

## ping命令测试

`ping baidu.com`

![image-20230624094709661](D:\大三冲刺\计算机网络\实验\lab5\image-20230624094709661.png)

## tracetr追踪

`tracert baidu.com`

![image-20230624095031501](D:\大三冲刺\计算机网络\实验\lab5\image-20230624095031501.png)

## WireShark开始捕获

使用icmp过滤，同时开启Resolve network names，重复上述1、2步骤，结果如下

![image-20230624095136046](D:\大三冲刺\计算机网络\实验\lab5\image-20230624095136046.png)

各字段描述如下：

![image-20230624095412729](D:\大三冲刺\计算机网络\实验\lab5\image-20230624095412729.png)

<center>Type表示消息类型，request为8，reply为0；Checksum为校验和表示校验码；Sequence Number用于链接数据报，连续的request和reply包会增加1；Data为数据部分，长度可变</center>

## 查看TTL超时的包

WireShark中用黑色标识

![image-20230624100224707](D:\大三冲刺\计算机网络\实验\lab5\image-20230624100224707.png)

## TTL超时包的结构图

| Type   | Code   | Checksum | Unused | IP      | ICMP   |
| ------ | ------ | -------- | ------ | ------- | ------ |
| 1 Byte | 1 Byte | 2 Byte   | 4 Byte | 20 Byte | 8 Byte |

IP结构参见实验4



# 实验结果

## ICMP 回显请求和回显应答数据包的 Type/Code 值分别是什么

请求包Type/Code为0x0800；应答包为0x0000

## 如何比较一个回显请求的标识符和序列号和对应的回声回复

一个请求包对应的应答包的Seq相同

## Identifier 和 Sequence Number 如何比较连续的 echo request 数据包

连续的请求应答包在Sequence Number会增加1

## echo reply中的数据和echo request中的数据是一样的还是不同的

相同

## ICMP TTL超出数据报的类型/代码值

Type: 11 (Time-to-live exceeded)

## 说明如果接收者不提前知道期 ICMP 消息的结构，如何安全地找到并处理所有 ICMP 字段。

ICMP在沟通之中，主要是透过不同的类别(Type)与代码(Code)让机器来识别不同的连线状况，从而对应不同的ICMP消息格式。

## 超时数据包的ICMP头长度

![image-20230624100907520](D:\大三冲刺\计算机网络\实验\lab5\image-20230624100907520.png)

如图所示，8Byte

## ICMP 有效载荷包含一个 IP 报头。 此标头中的 TTL 值是多少

![image-20230624101020374](D:\大三冲刺\计算机网络\实验\lab5\image-20230624101020374.png)

TTL=1。数据包每经过一个路由器TTL将会减1，当TTL为0时将丢弃这个包。所以此时TTL=1的包经过处理后TTl将变为0，路由器将会丢弃此IP包并向IP包的发送者发送 ICMP time exceeded消息。

## 计算机(源)如何从一个TTL超出的数据包中学习沿路径的路由器的IP地址

TTL超时包的负载部分的IP报头里面有两端的路由器IP地址。

1. 从源地址发出一个ICMP请求回显（ICMP Echo Request）数据包到目的地址，并将TTL设置为1；
2. 到达路由器时，将TTL减1；
3. 当TTL变为0时，包被丢弃，路由器向源地址发回一个ICMP超时通知（ICMP Time Exceeded Message），内含发送IP包的源地址，IP包的所有内容及路由器的IP地址；
4. 当源地址收到该ICMP包时，显示这一跳路由信息；
5. 重复1～5，并每次设置TTL加1；
6. 直至目标地址收到探测数据包，并返回ICMP回应答复（ICMP Echo Reply）；
7. 当源地址收到ICMP Echo Reply包时停止tracert

## 沿着traceroute探测的路径，每个路由器要探测多少次

Traceroute每跳默认发送3个探测包。

## 计算机(源)是如何发送一个请求包来寻找(通过触发TTL超时响应)路由器N沿着路径跳转到目的地的

![image-20230624101820480](D:\大三冲刺\计算机网络\实验\lab5\image-20230624101820480.png)

如图，源地址172.23.151.28向目的地址39.156.66.10发送ICMP请求回显（ICMP Echo Request）数据包，每跳默认发送3个，TTL设置为1；数据包遇到路由器之后，被丢弃，返回Time tolive exceeded超时通知，解析出路由器IP地址172.19.251.13。源地址再发数据包，设置TTL=2，从而解析出第二跳路由172.16.201.66。同理，解析出后续路由ip。

# 实验反思

通过本次实验，我深入了解了ICMP（互联网控制信息协议）的使用方法。ICMP作为IP的一个配套协议，在处理错误和测试情况时起到了重要的作用，帮助IP执行其功能。在实验过程中，我使用了ping命令测试和tracert命令追踪，并使用WireShark进行捕获和分析。通过分析捕获的数据包，我了解了ICMP数据包的结构和各字段的含义，包括Type、Code、Checksum、Sequence Number和Data等。我还学会了如何比较回显请求的标识符和序列号以及对应的回声回复，以及如何比较连续的echo request数据包。此外，我还了解了ICMP TTL超出数据报的类型/代码值和超时数据包的ICMP头长度，以及如何安全地处理所有ICMP字段。最后，我学会了通过TTL超时数据包来学习沿路径的路由器的IP地址，并了解了traceroute探测的路径和每个路由器要探测的次数。通过本次实验，我加深了对ICMP协议的理解，提高了实验操作和数据分析的能力。
