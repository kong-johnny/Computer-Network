<div class="cover" style="page-break-after:always;font-family:方正公文仿宋;width:100%;height:100%;border:none;margin: 0 auto;text-align:center;">
    <div style="width:60%;margin: 0 auto;height:0;padding-bottom:10%;">
        </br>
        <img src="D:\大三冲刺\计算机网络\实验\校名.png" alt="校名" style="width:100%;"/>
    </div>
    </br></br></br></br></br>
    <div style="width:60%;margin: 0 auto;height:0;padding-bottom:40%;">
        <img src="D:\大三冲刺\计算机网络\实验\校徽.png" alt="校徽" style="width:100%;"/>
	</div>
    </br></br></br></br></br></br></br></br>
    <span style="font-family:华文黑体Bold;text-align:center;font-size:20pt;margin: 10pt auto;line-height:30pt;">第7次实验：DHCP</span>
    <p style="text-align:center;font-size:14pt;margin: 0 auto">实验报告 </p>
    </br>
    </br>
    <table style="border:none;text-align:center;width:72%;font-family:仿宋;font-size:14px; margin: 0 auto;">
    <tbody style="font-family:方正公文仿宋;font-size:12pt;">
    	<tr style="font-weight:normal;"> 
    		<td style="width:20%;text-align:right;">题　　目</td>
    		<td style="width:2%">：</td> 
    		<td style="width:40%;font-weight:normal;border-bottom: 1px solid;text-align:center;font-family:华文仿宋">DHCP </td>     </tr><tr style="font-weight:normal;"> 
		<td style="width:20%;text-align:right;">授课教师</td>
		<td style="width:2%">：</td> 
		<td style="width:40%;font-weight:normal;border-bottom: 1px solid;text-align:center;font-family:华文仿宋">肖明忠 </td>     </tr>
	<tr style="font-weight:normal;"> 
		<td style="width:20%;text-align:right;">姓　　名</td>
		<td style="width:2%">：</td> 
		<td style="width:40%;font-weight:normal;border-bottom: 1px solid;text-align:center;font-family:华文仿宋"> 段欣然</td>     </tr>
	<tr style="font-weight:normal;"> 
		<td style="width:20%;text-align:right;">日　　期</td>
		<td style="width:2%">：</td> 
		<td style="width:40%;font-weight:normal;border-bottom: 1px solid;text-align:center;font-family:华文仿宋">2023.5.20</td>     </tr>
</tbody>              
</table></div>







<!-- 注释语句：导出PDF时会在这里分页 -->






<center><div style='height:2mm;'></div><div style="font-family:华文楷体;font-size:14pt;">段欣然，202011081033</div></center>
<center><span style="font-family:华文楷体;font-size:9pt;line-height:9mm">北京师范大学 人工智能学院</span>
</center>
<div>
<div style="width:52px;float:left; font-family:方正公文黑体;">目的：</div> 
<div style="overflow:hidden; font-family:华文楷体;">要看DHCP（动态主机配置协议）是如何工作的。DHCP是一个重要的胶合协议，用于为你的计算机配置一个IP地址以及其他信息。用来为你的计算机配置一个IP地址，以及其他信息。它在你的课文的第5.6.4节中有所涉及。在做这个实验之前，先回顾一下这些章节。
</div>
<div>
<div style="width:52px;float:left; font-family:方正公文黑体;">环境：</div> 
<div style="overflow:hidden; font-family:华文楷体;">WireShark；ipconfig </div>
</div>




<hr>													
<center><b><font size=6>实验报告正文</font></b></center>



# 实验过程

## WireShark捕获

使用`udp port 67`过滤

## 命令行输入config

```sh
ipconfig \release
ipconfig \renew
```

![image-20230624183907201](D:\大三冲刺\计算机网络\实验\lab7\image-20230624183907201.png)

捕获数据包如下：

![image-20230624183921168](D:\大三冲刺\计算机网络\实验\lab7\image-20230624183921168.png)

## 查看Request包

![image-20230624184051306](D:\大三冲刺\计算机网络\实验\lab7\image-20230624184051306.png)

各字段含义如下：

| Message Type   | **值为Boot Request，用于从PC发送到DHCP服务器的所有DHCP报文。** |
| -------------- | ------------------------------------------------------------ |
| Transaction ID | 所有DHCP报文在客户端和服务器之间的特定交换携带相同的事务ID；即两端都知道报文属于该交换，而不是另一个并发的DHCP操作。 |
| 一系列的IP     | 这些字段用于携带IP地址                                       |
| Magic Cookie   | 它携带一个值，表示报文的其余部分包含一系列DHCP option        |
| DHCP option    | 每个DHCP选项都是自包含的，有一个类型代码表示它所代表的内容，以及长度和值。第一个选项是DHCP Message Type，表示所携带的DHCP报文的类型。其他选项根据不同的DHCP报文类型而不同。例如，DHCP Request将有一个被请求的IP地址选项来请求一个特定的地址，DHCP Ack将有一个IP地址租期选项来说明IP地址被分配的时间。 |



# 实验结果

## BOOTP Message Type字段的两个值是什么

Request是01，ACK是02

## Transaction ID字段有多长

Transaction ID有四个字节。由不同计算机进行的并发DHCP操作选择的Transaction ID可能相同。Transaction ID是由客户端随机生成，然后插入DHCP DISCOVER消息的xid字段，服务器从DHCP DISCOVER消息解析得到xid值，把xid值插入到DHCP OFFER消息的xid字段，发送DHCP OFFER报文到请求客户端。如果DHCP OFFER消息中的xid值与最近发送DHCP DISCOVER消息中的xid值不同，那么客户端必须忽略这个DHCP OFFER。接收到的任何DHCPACK须丢弃。

## 携带被分配给客户端的IP地址的字段的名称是什么

Your (client) IP address: 0.0.0.0 (0.0.0.0)

## 代表DHCP的Magic Cookie的值是多少

![image-20230624184735562](D:\大三冲刺\计算机网络\实验\lab7\image-20230624184735562.png)

0x 63 82 53 63

## 第一个DHCP选项是DHCP报文类型。这个类型选项值代表什么

DHCP: Request (3)

DHCP: ACK (5)

## DHCP请求通常会有一个客户端标识符选项。看这个选项的值。如何能识别客户端

![image-20230624184931412](D:\大三冲刺\计算机网络\实验\lab7\image-20230624184931412.png)

Option Client Identifier包含服务器MAC地址

## DHCP ACK通常有一个服务器标识符选项。看这个选项的值。它如何识别服务器

![image-20230624185131275](D:\大三冲刺\计算机网络\实验\lab7\image-20230624185131275.png)

Option Server Identifier包含服务器IP地址

## 哪个选项值代表被请求的IP地址选项?对于IP地址租期选项呢

DHCP Request有Requested IP Address来请求一个特定的地址；
DHCP Ack有IP Address Lease Time来说说明IP地址被分配的时间。

## DHCP消息的接收方如何知道它已经到达了最后一个选项

End选项标识

## DHCP客户端使用什么端口号，DHCP服务器使用什么端口号

客户端使用68，服务端使用67

## Request消息上的源IP地址是什么

是0.0.0.0这是一个特殊的值，表示“这个网络上的这个主机”，用于初始化。

## Request消息上的目的IP地址是什么

是255.255.255.255它也是一个预留值，在本地网络的任何地方都可以到达DHCP服务器。

## Ethernet source字段放在request消息的什么字段上，Destination字段呢

Source放在Client MAC address上。
Destination是保留地址。

## 计算机如何判断它收到的DHCP报文是作为对其DHCP请求报文的应答，还是作为对另一台计算机的应答

对比它的Transition ID，如果该ID是之前DHCP发出过的ID，则是对请求报文的应答，否则的话不是自己的应答，就丢弃。

# 实验反思

我通过实验习得了练习要求的内容，并完成了实验报告。在实验过程中，我使用WireShark捕获数据包，并通过命令行输入config来进行操作。我查看了Request包的各个字段含义，并总结如下：

- Message Type字段的值为Boot Request，表示从PC发送到DHCP服务器的所有DHCP报文。
- Transaction ID字段有四个字节，用于标识DHCP报文在客户端和服务器之间的特定交换。
- 携带被分配给客户端的IP地址的字段的名称是Your (client) IP address。
- 代表DHCP的Magic Cookie的值为0x 63 82 53 63。
- 第一个DHCP选项是DHCP报文类型，该选项的值代表不同的DHCP报文类型，如Request和ACK。
- DHCP请求通常会有一个客户端标识符选项，其中包含服务器MAC地址来识别客户端。
- DHCP ACK通常有一个服务器标识符选项，其中包含服务器IP地址来识别服务器。
- 被请求的IP地址选项对应DHCP Request报文，而IP地址租期选项对应DHCP ACK报文。
- DHCP消息的接收方通过End选项来知道它已经到达了最后一个选项。

通过这次实验，我对DHCP协议的工作原理有了更深入的了解。我能够正确解析和理解捕获的数据包，并提取其中的关键信息。在实验反思中，我可以进一步思考实验过程中遇到的问题、改进的方法以及对实验结果的分析。这次实验提高了我的实验技能和对网络协议的理解能力。
