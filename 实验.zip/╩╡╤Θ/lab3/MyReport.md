<div class="cover" style="page-break-after:always;font-family:方正公文仿宋;width:100%;height:100%;border:none;margin: 0 auto;text-align:center;">
    <div style="width:60%;margin: 0 auto;height:0;padding-bottom:10%;">
        </br>
        <img src="D:\大三冲刺\计算机网络\实验\校名.png" alt="校名" style="width:100%;"/>
    </div>
    </br></br></br></br></br>
    <div style="width:60%;margin: 0 auto;height:0;padding-bottom:40%;">
        <img src="D:\大三冲刺\计算机网络\实验\校徽.png" alt="校徽" style="width:100%;"/>
	</div>
    </br></br></br></br></br></br></br></br>
    <span style="font-family:华文黑体Bold;text-align:center;font-size:20pt;margin: 10pt auto;line-height:30pt;">第3次实验：802.11</span>
    <p style="text-align:center;font-size:14pt;margin: 0 auto">实验报告 </p>
    </br>
    </br>
    <table style="border:none;text-align:center;width:72%;font-family:仿宋;font-size:14px; margin: 0 auto;">
    <tbody style="font-family:方正公文仿宋;font-size:12pt;">
    	<tr style="font-weight:normal;"> 
    		<td style="width:20%;text-align:right;">题　　目</td>
    		<td style="width:2%">：</td> 
    		<td style="width:40%;font-weight:normal;border-bottom: 1px solid;text-align:center;font-family:华文仿宋">802.11 </td>     </tr><tr style="font-weight:normal;"> 
		<td style="width:20%;text-align:right;">授课教师</td>
		<td style="width:2%">：</td> 
		<td style="width:40%;font-weight:normal;border-bottom: 1px solid;text-align:center;font-family:华文仿宋">肖明忠 </td>     </tr>
	<tr style="font-weight:normal;"> 
		<td style="width:20%;text-align:right;">姓　　名</td>
		<td style="width:2%">：</td> 
		<td style="width:40%;font-weight:normal;border-bottom: 1px solid;text-align:center;font-family:华文仿宋"> 段欣然</td>     </tr>
	<tr style="font-weight:normal;"> 
		<td style="width:20%;text-align:right;">日　　期</td>
		<td style="width:2%">：</td> 
		<td style="width:40%;font-weight:normal;border-bottom: 1px solid;text-align:center;font-family:华文仿宋">2023.4.1</td>     </tr>
</tbody>              
</table></div>







<!-- 注释语句：导出PDF时会在这里分页 -->




# 

<center><div style='height:2mm;'></div><div style="font-family:华文楷体;font-size:14pt;">段欣然，202011081033</div></center>
<center><span style="font-family:华文楷体;font-size:9pt;line-height:9mm">北京师范大学 人工智能学院</span>
</center>
<div>
<div style="width:52px;float:left; font-family:方正公文黑体;">目的：</div> 
<div style="overflow:hidden; font-family:华文楷体;">探索802.11的物理层、链接层和管理功能。它被广泛用于将移动设备无线连接到互联网，并在课文的第4.4节中涉及。首先回顾该部分
</div>
<div>
<div style="width:52px;float:left; font-family:方正公文黑体;">环境：</div> 
<div style="overflow:hidden; font-family:华文楷体;">WireShark </div>
</div>




<hr>													
<center><b><font size=6>实验报告正文</font></b></center>



# 实验过程

**本实验直接使用作者实验结果进行分析实验过程略**

查看捕获数据包信息如下

![image-20230623113115429](D:\大三冲刺\计算机网络\实验\lab3\image-20230623113115429.png)

# 实验结果

## **主AP的SSID**

![image-20230623114309952](D:\大三冲刺\计算机网络\实验\lab3\image-20230623114309952.png)

可以看出大量Beacon frame中的SSID都为djw，所以主AP的SSID为djw

## 主AP的Beacon帧多久发送一次

![image-20230623114753593](D:\大三冲刺\计算机网络\实验\lab3\image-20230623114753593.png)

可以直接读出Beacon帧间隔0.1024s发送一次

## 主AP支持什么数据速率

![image-20230623115005959](D:\大三冲刺\计算机网络\实验\lab3\image-20230623115005959.png)

Tag: Supported Rates 1(B), 2(B), 5.5(B), 11(B), 18, 24, 36, 54, [Mbit/sec]

## 信标帧的传输速率是多少

![image-20230623115238399](D:\大三冲刺\计算机网络\实验\lab3\image-20230623115238399.png)

Data Rate: 1.0 Mb/s

## Association 请求/响应帧的类型和子类型值

![image-20230623115940903](D:\大三冲刺\计算机网络\实验\lab3\image-20230623115940903.png)

![image-20230623120215637](D:\大三冲刺\计算机网络\实验\lab3\image-20230623120215637.png)

Type/Subtype: Authentication (0x000b)

Authentication Algorithm: Open System (0) 这意味着它不提供安全密钥

## Probe请求/Probe响应帧的类型和子类型值是什么？

![image-20230623120632228](D:\大三冲刺\计算机网络\实验\lab3\image-20230623120632228.png)

Type/Subtype: Probe Request (0x0004)

# 实验反思

通过本次实验，我深入了解了802.11无线网络的物理层、链接层和管理功能。我通过分析捕获的数据包信息，了解了主AP的SSID、Beacon帧的发送间隔、主AP支持的数据速率，以及信标帧和关联请求/响应帧的类型和子类型值。同时，我还了解了探求请求/探求响应帧的类型和子类型值。通过这些实验结果，我对802.11无线网络的工作原理和通信过程有了更深入的理解。

在实验中，我使用了WireShark工具进行数据包分析，通过查看不同类型的帧和其相关信息，我能够推断出无线网络的一些重要参数和属性。这为我进一步学习和研究无线网络提供了基础。

通过这次实验，我不仅加深了对802.11无线网络的理解，还提升了我的数据分析和解释实验结果的能力。我意识到通过实际实验和数据分析，可以更加深入地理解理论知识，并将其应用到实际场景中。

总的来说，通过这次实验，我成功地掌握了实验要求的内容，并通过实验报告记录了实验过程和结果。这次实验对于我深入了解和掌握802.11无线网络以及网络数据分析方法具有重要意义。
