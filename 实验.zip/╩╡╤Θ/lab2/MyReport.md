<div class="cover" style="page-break-after:always;font-family:方正公文仿宋;width:100%;height:100%;border:none;margin: 0 auto;text-align:center;">
    <div style="width:60%;margin: 0 auto;height:0;padding-bottom:10%;">
        </br>
        <img src="D:\大三冲刺\计算机网络\实验\校名.png" alt="校名" style="width:100%;"/>
    </div>
    </br></br></br></br></br>
    <div style="width:60%;margin: 0 auto;height:0;padding-bottom:40%;">
        <img src="D:\大三冲刺\计算机网络\实验\校徽.png" alt="校徽" style="width:100%;"/>
	</div>
    </br></br></br></br></br></br></br></br>
    <span style="font-family:华文黑体Bold;text-align:center;font-size:20pt;margin: 10pt auto;line-height:30pt;">第2次实验：Ethernet </span>
    <p style="text-align:center;font-size:14pt;margin: 0 auto">实验报告 </p>
    </br>
    </br>
    <table style="border:none;text-align:center;width:72%;font-family:仿宋;font-size:14px; margin: 0 auto;">
    <tbody style="font-family:方正公文仿宋;font-size:12pt;">
    	<tr style="font-weight:normal;"> 
    		<td style="width:20%;text-align:right;">题　　目</td>
    		<td style="width:2%">： </td> 
    		<td style="width:40%;font-weight:normal;border-bottom: 1px solid;text-align:center;font-family:华文仿宋">Ethernet </td>     </tr><tr style="font-weight:normal;"> 
		<td style="width:20%;text-align:right;">授课教师</td>
		<td style="width:2%">：</td> 
		<td style="width:40%;font-weight:normal;border-bottom: 1px solid;text-align:center;font-family:华文仿宋">肖明忠 </td>     </tr>
	<tr style="font-weight:normal;"> 
		<td style="width:20%;text-align:right;">姓　　名</td>
		<td style="width:2%">：</td> 
		<td style="width:40%;font-weight:normal;border-bottom: 1px solid;text-align:center;font-family:华文仿宋"> 段欣然</td>     </tr>
	<tr style="font-weight:normal;"> 
		<td style="width:20%;text-align:right;">日　　期</td>
		<td style="width:2%">：</td> 
		<td style="width:40%;font-weight:normal;border-bottom: 1px solid;text-align:center;font-family:华文仿宋">2023.3.15</td>     </tr>
</tbody>              
</table></div>







<!-- 注释语句：导出PDF时会在这里分页 -->






<center><div style='height:2mm;'></div><div style="font-family:华文楷体;font-size:14pt;">段欣然，202011081033</div></center>
<center><span style="font-family:华文楷体;font-size:9pt;line-height:9mm">北京师范大学 人工智能学院</span>
</center>
<div>
<div style="width:52px;float:left; font-family:方正公文黑体;">目的：</div> 
<div style="overflow:hidden; font-family:华文楷体;">要探索以太网帧的细节。以太网是一种流行的链路层协议，在你的课文的第4.3节中有介绍；现代计算机连接到以太网交换机（第4.3.4节），而不是使用经典的以太网（第4.3.2节）。在做这个实验之前，先复习一下§4.3节。
</div>
<div>
<div style="width:52px;float:left; font-family:方正公文黑体;">环境：</div> 
<div style="overflow:hidden; font-family:华文楷体;">WireShark；Ping </div>
</div>




<hr>													
<center><b><font size=6>实验报告正文</font></b></center>



# 实验过程

## 设置WireShark选项

![image-20230622220653020](D:\大三冲刺\计算机网络\实验\lab2\image-20230622220653020.png)

![image-20230622220703235](D:\大三冲刺\计算机网络\实验\lab2\image-20230622220703235.png)

使用icmp进行过滤。

## 进行`Ping`操作

![image-20230622220810061](D:\大三冲刺\计算机网络\实验\lab2\image-20230622220810061-16874428916961.png)

## 观察捕获结果

![image-20230622221048819](D:\大三冲刺\计算机网络\实验\lab2\image-20230622221048819-16874430620222.png)

## 各字段信息解释如下

1. Destination：目的地址
2. Source：源地址
3. Type：表明使用的是IPv4还是IPv6
4. Data：可变长
5. CheckSum：校验位

# 实验结果

## Ethernet帧结构

![image-20230622221509017](D:\大三冲刺\计算机网络\实验\lab2\image-20230622221509017.png)

| 目的地址        | 源地址 | 类型 | 数据             | ...  | 校验码 |
| --------------- | ------ | ---- | ---------------- | ---- | ------ |
| 6B              | 6B     | 2B   | ...              | ...  | 4B     |
| Ethernet Header |        |      | Ethernet Payload |      |        |

## 显示PC、路由器和远程服务器的相对位置

![image-20230622223030899](D:\大三冲刺\计算机网络\实验\lab2\image-20230622223030899.png)

## 广播以太网地址

![image-20230622224140945](D:\大三冲刺\计算机网络\实验\lab2\image-20230622224140945.png)

![image-20230622224204261](D:\大三冲刺\计算机网络\实验\lab2\image-20230622224204261.png)

可以从Destination字段中看到BroadCast是使用ff:ff:ff:ff:ff:ff（全1）进行标识。

![image-20230622224429541](D:\大三冲刺\计算机网络\实验\lab2\image-20230622224429541.png)

以太网地址的第八位用来确定它是单播还是多播/广播

# 实验反思

在实验中，我使用WireShark进行数据包捕获和分析，并通过Ping操作观察和解释捕获结果。我了解了以太网帧的结构和字段含义，包括目的地址、源地址、类型、数据和校验码等。我还学习了以太网地址的分类和广播地址的特点。

通过实验，我进一步加深了对以太网的理解，掌握了以太网帧的结构和字段的含义，并能够解释捕获结果中的各个字段信息。我还了解了广播以太网地址的特点和使用方式。

在实验过程中，我对WireShark的设置选项和两种过滤进行了配置，并进行了Ping操作来观察和捕获网络数据包。我通过实验报告的编写，整理了实验过程和结果，并进行了分析和解释。

通过本次实验，我不仅加深了对以太网的理论知识的理解，还提升了实际操作和数据分析的能力。我相信这些学习和实践将对我今后在计算机网络领域的学习和研究有很大的帮助。
