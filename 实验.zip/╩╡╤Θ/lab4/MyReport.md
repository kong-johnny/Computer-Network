<div class="cover" style="page-break-after:always;font-family:方正公文仿宋;width:100%;height:100%;border:none;margin: 0 auto;text-align:center;">
    <div style="width:60%;margin: 0 auto;height:0;padding-bottom:10%;">
        </br>
        <img src="D:\大三冲刺\计算机网络\实验\校名.png" alt="校名" style="width:100%;"/>
    </div>
    </br></br></br></br></br>
    <div style="width:60%;margin: 0 auto;height:0;padding-bottom:40%;">
        <img src="D:\大三冲刺\计算机网络\实验\校徽.png" alt="校徽" style="width:100%;"/>
	</div>
    </br></br></br></br></br></br></br></br>
    <span style="font-family:华文黑体Bold;text-align:center;font-size:20pt;margin: 10pt auto;line-height:30pt;">第4次实验：IPv4</span>
    <p style="text-align:center;font-size:14pt;margin: 0 auto">实验报告 </p>
    </br>
    </br>
    <table style="border:none;text-align:center;width:72%;font-family:仿宋;font-size:14px; margin: 0 auto;">
    <tbody style="font-family:方正公文仿宋;font-size:12pt;">
    	<tr style="font-weight:normal;"> 
    		<td style="width:20%;text-align:right;">题　　目</td>
    		<td style="width:2%">：</td> 
    		<td style="width:40%;font-weight:normal;border-bottom: 1px solid;text-align:center;font-family:华文仿宋">IPv4 </td>     </tr><tr style="font-weight:normal;"> 
		<td style="width:20%;text-align:right;">授课教师</td>
		<td style="width:2%">：</td> 
		<td style="width:40%;font-weight:normal;border-bottom: 1px solid;text-align:center;font-family:华文仿宋">肖明忠 </td>     </tr>
	<tr style="font-weight:normal;"> 
		<td style="width:20%;text-align:right;">姓　　名</td>
		<td style="width:2%">：</td> 
		<td style="width:40%;font-weight:normal;border-bottom: 1px solid;text-align:center;font-family:华文仿宋"> 段欣然</td>     </tr>
	<tr style="font-weight:normal;"> 
		<td style="width:20%;text-align:right;">日　　期</td>
		<td style="width:2%">：</td> 
		<td style="width:40%;font-weight:normal;border-bottom: 1px solid;text-align:center;font-family:华文仿宋">2023.4.15</td>     </tr>
</tbody>              
</table></div>







<!-- 注释语句：导出PDF时会在这里分页 -->



# 

<center><div style='height:2mm;'></div><div style="font-family:华文楷体;font-size:14pt;">段欣然，202011081033</div></center>
<center><span style="font-family:华文楷体;font-size:9pt;line-height:9mm">北京师范大学 人工智能学院</span>
</center>
<div>
<div style="width:52px;float:left; font-family:方正公文黑体;">目的：</div> 
<div style="overflow:hidden; font-family:华文楷体;">要了解IP（互联网协议）的细节。IP是整个互联网使用的网络层协议。我们将研究IP版本4，因为它是无处不在的，而IP版本6是部分部署的。部份部署。文本中的第5.6.1节至第5.6.3节涉及IP。在做这个实验之前，请回顾这些章节。
</div>
<div>
<div style="width:52px;float:left; font-family:方正公文黑体;">环境：</div> 
<div style="overflow:hidden; font-family:华文楷体;">WireShark；wget/curl；traceroute/tracert </div>
</div>




<hr>													
<center><b><font size=6>实验报告正文</font></b></center>



# 实验过程

## wget网站测试是否可达

![image-20230623221722359](D:\大三冲刺\计算机网络\实验\lab4\image-20230623221722359.png)

## tracert跟踪记录

![image-20230623221911745](D:\大三冲刺\计算机网络\实验\lab4\image-20230623221911745.png)

## 开始捕获

用tcp port 80过滤，启用resolve network name，再次wget得到结果如下

![image-20230623222340331](D:\大三冲刺\计算机网络\实验\lab4\image-20230623222340331.png)

## IP各字段解释如下

![image-20230623222958706](D:\大三冲刺\计算机网络\实验\lab4\image-20230623222958706.png)

Version：版本号（IPv4）
Header Length：IP包头长度，IP包头的长度= IP头部长度（单位为bit）/(8*4)。本次实验为5， IP包头长度为20字节。
Differentiation Services：包含位标志，表示数据包是否应该是处理路由器的服务质量和拥塞指示。
Total Length：IP包总长，这里是52字节。
Identifier：用于分组片段，当一个大的IP数据包作为多个更小的片段发送，称为片段。Flags和Fragment偏移量字段，也与碎片相关。观察共享字节。
Fragment Offset：片偏移，这里是00000 0000 0000。表示该IP包在该组分片包中位置，接收端靠此来组装还原IP包。
Time to Live：生存时间，这里是64。当IP包进行传送时，先会对该字段赋予某个特定的值。当IP包经过每一个沿途的路由器的时候，每个沿途的路由器会将IP包的TTL值减少1。如果TTL减少为0，则该IP包会被丢弃。这个字段可以防止由于路由环路而导致IP包在网络中不停被转发。
Protocol：协议，这里是0x06表示TCP协议
Header Checksum：头部校验，这里是0x0000。16bit的首部校验和字段用来使接收端检验收到的报文是否正确。该字段只对IP首部计算校验和不包含后面的数据字段。原因是IP的上层协议比如ICMP、IGMP、TCP、UDP协议的各自首部中均含有同时覆盖首部和数据的校验和。
Source：源地址
Destination：目的地址

# 实验结果

## 计算机和远程服务器的IP地址

我的PC：172.23.151.28

远程服务器：110.242.68.3

## **总长度字段是否包括IP头加上IP有效载荷，或只是IP有效载荷**

包括IP头和IP有效载荷

## **对于不同的数据包，Identification字段的值是如何改变或保持不变的**

同个连接中的Identification字段可能相同，因为可能原来是一个包，只是后来被分片了。不同传输方向上相同可能性不大，因为发送端和接收端标识字段是各自标识的，且标识字段的初始值是随机的。所以它对TCP连接中的每个数据包都有不同的分组。Identification字段的规律是，IP软件在存储器中维持一个计数器，每产生一个数据报，计数器就加1，并将此值赋给标识字段。分片，保持一致。

## **从您的计算机发送的数据包的TTL字段的初始值是多少**

本实验中，TTL字段初始值为128。数据报在转发过程中每经过一个路由，该值就被路由器减1。当TTL值减为0时，路由器将丢弃数据报，并向源端发送一个ICMP差错报文。

## **如何通过查看包来判断它没有被分片**

如果收到的 IP 报头中 Fragmentation Flags 为 1 则未分片；而如果收到的IP报头的Fragment Flag为0，则表明其是被分片的。

##  **IP报头的长度是多少，这是如何编码进报头长度字段**

本实验中ip报头长度为20，对应为0101 表示4，ip报头长度以4字节进行计数。因而总长度为4x5=20B

## **IP包结构图纸，以及tracert输出结果**

| Version | Header Length | Type of service | Total Length | Identifier | Flags |
| ------- | ------------- | --------------- | ------------ | ---------- | ----- |
| 4 Bit   | 4 Bit         | 1 Byte          | 2 Byte       | 2 Byte     | 3 Bit |

| Fragment Offset | TTL    | Protocol | Header Checksum | Source | Destination |
| --------------- | ------ | -------- | --------------- | ------ | ----------- |
| 13 Bit          | 1 Byte | 1 Byte   | 2 Byte          | 4 Byte | 4 Byte      |

## **画网络路径**

我的PC：172.23.151.28

```sh
到 www.a.shifen.com [110.242.68.4] 的路由:

  1     *        *        *     请求超时。
  2     5 ms    14 ms     4 ms  172.19.251.13
  3     6 ms     5 ms     4 ms  172.16.201.66
  4     8 ms     3 ms     5 ms  61.49.176.89
  5     *        *        *     请求超时。
  6     *        *        *     请求超时。
  7    11 ms    10 ms     9 ms  219.158.11.94
  8    16 ms    13 ms    14 ms  110.242.66.178
  9    16 ms    15 ms    30 ms  221.194.45.134
 10     *        *        *     请求超时。
 11     *        *        *     请求超时。
 12     *        *        *     请求超时。
 13     *        *        *     请求超时。
 14    15 ms    13 ms    11 ms  110.242.68.4
```



2，3均为本地服务器，4为北京市联通服务器，其余均为各省联通服务器

## 校验码

![image-20230623225512792](D:\大三冲刺\计算机网络\实验\lab4\image-20230623225512792.png)

校验过程：

1. 将字段分成10个2Byte，即4500 0028 d32c 4000 8006 0000 ac17 971c 6ef2 4403
2. 将这十组数字相加，即 0x3ce82
3. 不足8位用0补齐再相加：0003 + ce82 = ce85
4. 二进制按位取反：~ce85 = 317a
5. 与校验码0000不同，所以校验不正确，与实际结果相符

# 实验反思

我通过实验成功地学习和掌握了IP（互联网协议）的相关内容。在实验报告中，我使用了wget、tracert和WireShark等工具，对IP进行了详细研究和分析。实验过程中，我测试了网站的可达性，并进行了tracert跟踪记录。我还捕获了数据包，并解释了IP各字段的含义，包括版本号、IP包头长度、不同服务、总长度、标识符、片偏移、生存时间、协议和头部校验等。实验结果中，我列出了计算机和远程服务器的IP地址，并回答了关于Identification字段、TTL字段、分片判断和IP报头长度的问题。此外，我提供了IP包结构图示、tracert输出结果和网络路径的描述。最后，我还包括了校验码的截图。

通过这次实验，我加深了对IP协议的理解，掌握了实际应用工具和技术进行IP分析的方法，提高了自己在计算机网络领域的实践能力和知识水平。
