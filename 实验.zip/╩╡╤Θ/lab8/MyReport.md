<div class="cover" style="page-break-after:always;font-family:方正公文仿宋;width:100%;height:100%;border:none;margin: 0 auto;text-align:center;">
    <div style="width:60%;margin: 0 auto;height:0;padding-bottom:10%;">
        </br>
        <img src="D:\大三冲刺\计算机网络\实验\校名.png" alt="校名" style="width:100%;"/>
    </div>
    </br></br></br></br></br>
    <div style="width:60%;margin: 0 auto;height:0;padding-bottom:40%;">
        <img src="D:\大三冲刺\计算机网络\实验\校徽.png" alt="校徽" style="width:100%;"/>
	</div>
    </br></br></br></br></br></br></br></br>
    <span style="font-family:华文黑体Bold;text-align:center;font-size:20pt;margin: 10pt auto;line-height:30pt;">第8次实验：UDP</span>
    <p style="text-align:center;font-size:14pt;margin: 0 auto">实验报告 </p>
    </br>
    </br>
    <table style="border:none;text-align:center;width:72%;font-family:仿宋;font-size:14px; margin: 0 auto;">
    <tbody style="font-family:方正公文仿宋;font-size:12pt;">
    	<tr style="font-weight:normal;"> 
    		<td style="width:20%;text-align:right;">题　　目</td>
    		<td style="width:2%">：</td> 
    		<td style="width:40%;font-weight:normal;border-bottom: 1px solid;text-align:center;font-family:华文仿宋">UDP </td>     </tr><tr style="font-weight:normal;"> 
		<td style="width:20%;text-align:right;">授课教师</td>
		<td style="width:2%">：</td> 
		<td style="width:40%;font-weight:normal;border-bottom: 1px solid;text-align:center;font-family:华文仿宋">肖明忠 </td>     </tr>
	<tr style="font-weight:normal;"> 
		<td style="width:20%;text-align:right;">姓　　名</td>
		<td style="width:2%">：</td> 
		<td style="width:40%;font-weight:normal;border-bottom: 1px solid;text-align:center;font-family:华文仿宋"> 段欣然</td>     </tr>
	<tr style="font-weight:normal;"> 
		<td style="width:20%;text-align:right;">日　　期</td>
		<td style="width:2%">：</td> 
		<td style="width:40%;font-weight:normal;border-bottom: 1px solid;text-align:center;font-family:华文仿宋">2023.5.30</td>     </tr>
</tbody>              
</table></div>







<!-- 注释语句：导出PDF时会在这里分页 -->



# 

<center><div style='height:2mm;'></div><div style="font-family:华文楷体;font-size:14pt;">段欣然，202011081033</div></center>
<center><span style="font-family:华文楷体;font-size:9pt;line-height:9mm">北京师范大学 人工智能学院</span>
</center>
<div>
<div style="width:52px;float:left; font-family:方正公文黑体;">目的：</div> 
<div style="overflow:hidden; font-family:华文楷体;">来看一下UDP（用户数据报协议）的细节。UDP是整个互联网上使用的一种传输协议。在不需要可靠性的情况下，作为TCP的替代品在互联网上使用。它在你的课文的第6.4节中有所涉及。在做这个实验之前，先复习一下这一部分
</div>
<div>
<div style="width:52px;float:left; font-family:方正公文黑体;">环境：</div> 
<div style="overflow:hidden; font-family:华文楷体;">WireShark；ipconfig；Browser </div>
</div>




<hr>													
<center><b><font size=6>实验报告正文</font></b></center>



# 实验过程

## WireShark捕获

使用`udp`过滤

## **浏览任意网站或拨打语音通话**

结果如下：

![image-20230624191155814](D:\大三冲刺\计算机网络\实验\lab8\image-20230624191155814.png)

## UDP数据包结构

UDP数据报包含两个部分：UDP首部和用户数据。UDP首部有8B，由4个字段组成，每个字段长度都是2B，具体如下所示。

| 源端口   | **在需要对方回信的的时候选用，不需要时全为0**                |
| -------- | ------------------------------------------------------------ |
| 目的端口 | 这是UDP消息的目标端口号和可能的名称。端口是UDP中唯一的寻址形式。在较低的IP层中使用IP地址识别计算机 |
| 长度     | UDP数据报的长度，最小是8（仅首部）                           |
| 校验和   | 检测UDP数据报在传输中是否有错。该字段是可选的，不想计算校验和的时候，校验和为全0. |

IP Header（40 B） + UDP Header（8 B）+ UDP Playload（变长）

# 实验结果

## 长度字段包括

UDP数据报的长度字段指的是首部加数据部分的总长度。即UDP的头和UDP的有效载荷

## UDP校验和有多少位

2 B，16位

## **整个UDP报头有多少字节**

8 B

## **给出该IP协议字段的值，该字段将上层协议标识为UDP**

![image-20230624191955058](D:\大三冲刺\计算机网络\实验\lab8\image-20230624191955058.png)

协议字段标明使用UDP协议，对应值为17

## **检查UDP消息然后给出使用的目的IP地址，当你的计算机既不是源IP地址也不是目的IP地址的时候。**

本实验中未观察到上述现象，查阅资料发现这种现象的出现与组播和广播有关

## **跟踪的UDP消息的典型大小是多少**

8 Byte

# 实验反思

在这个实验中，我使用WireShark工具捕获UDP数据包，并进行了浏览网站或拨打语音通话的实验。通过观察捕获到的UDP数据包，我深入了解了UDP数据报的结构，包括UDP首部和用户数据。我了解到UDP首部由8个字节组成，包含源端口、目的端口、长度和校验和等字段。我还了解到UDP报头的长度为8字节，校验和字段长度为2字节（16位）。此外，我还了解到UDP消息的典型大小通常为8字节。通过这次实验，我对UDP协议有了更深入的理解，并加深了对计算机网络中数据传输的认识。

总体而言，通过这次实验，我成功地完成了实验要求，并通过实验报告详细总结了实验过程和结果。我对UDP协议的工作原理和相关概念有了更深入的理解，这对我的学习和实践都具有积极的影响。
