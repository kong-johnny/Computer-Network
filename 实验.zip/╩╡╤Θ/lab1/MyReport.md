<div class="cover" style="page-break-after:always;font-family:方正公文仿宋;width:100%;height:100%;border:none;margin: 0 auto;text-align:center;">
    <div style="width:60%;margin: 0 auto;height:0;padding-bottom:10%;">
        </br>
        <img src="E:\大二要努力\历史兴衰\images-of-essay\bnu(word).png" alt="校名" style="width:100%;"/>
    </div>
    </br></br></br></br></br>
    <div style="width:60%;margin: 0 auto;height:0;padding-bottom:40%;">
        <img src="E:\大二要努力\历史兴衰\images-of-essay\bnu(pic).png" alt="校徽" style="width:100%;"/>
	</div>
    </br></br></br></br></br></br></br></br>
    <span style="font-family:华文黑体Bold;text-align:center;font-size:20pt;margin: 10pt auto;line-height:30pt;">第一次实验：Protocol Layers</span>
    <p style="text-align:center;font-size:14pt;margin: 0 auto">实验报告 </p>
    </br>
    </br>
    <table style="border:none;text-align:center;width:72%;font-family:仿宋;font-size:14px; margin: 0 auto;">
    <tbody style="font-family:方正公文仿宋;font-size:12pt;">
    	<tr style="font-weight:normal;"> 
    		<td style="width:20%;text-align:right;">题　　目</td>
    		<td style="width:2%">：</td> 
    		<td style="width:40%;font-weight:normal;border-bottom: 1px solid;text-align:center;font-family:华文仿宋">Protocol Layers </td>    </tr><tr style="font-weight:normal;"> 
		<td style="width:20%;text-align:right;">授课教师</td>
		<td style="width:2%">：</td> 
		<td style="width:40%;font-weight:normal;border-bottom: 1px solid;text-align:center;font-family:华文仿宋">肖明忠 </td>     </tr>
	<tr style="font-weight:normal;"> 
		<td style="width:20%;text-align:right;">姓　　名</td>
		<td style="width:2%">：</td> 
		<td style="width:40%;font-weight:normal;border-bottom: 1px solid;text-align:center;font-family:华文仿宋"> 段欣然</td>     </tr>
	<tr style="font-weight:normal;"> 
		<td style="width:20%;text-align:right;">日　　期</td>
		<td style="width:2%">：</td> 
		<td style="width:40%;font-weight:normal;border-bottom: 1px solid;text-align:center;font-family:华文仿宋">2023.3.1</td>     </tr>
</tbody>              
</table></div>






<!-- 注释语句：导出PDF时会在这里分页 -->





<center><div style='height:2mm;'></div><div style="font-family:华文楷体;font-size:14pt;">段欣然，202011081033</div></center>
<center><span style="font-family:华文楷体;font-size:9pt;line-height:9mm">北京师范大学 人工智能学院</span>
</center>
<div>
<div style="width:52px;float:left; font-family:方正公文黑体;">目的：</div> 
<div style="overflow:hidden; font-family:华文楷体;">了解协议和分层是如何在数据包中表示的。它们是构建文本的1.3和1.4中所涉及的网络的关键概念。
</div>
<div>
<div style="width:52px;float:left; font-family:方正公文黑体;">环境：</div> 
<div style="overflow:hidden; font-family:华文楷体;">Wireshark；wget </div>
</div>




<hr>													
<center><b><font size=6>实验报告正文</font></b></center>



# 实验过程

## 捕获跟踪

### *Pick a URL and fetch it with* wget *or* curl*.*

![image-20230307112756021](image-20230307112756021.png)

捕获结果如下

![image-20230307124743047](image-20230307124743047.png)

## 检查跟踪

![image-20230307125205008](image-20230307125205008.png)

协议为HTTP，是一个GET

![image-20230307130837733](image-20230307130837733.png)

另一个数据包，信息字段中有“200 OK”

## 数据包结构

![image-20230307130549964](image-20230307130549964.png)

- Ethernet占用14字节

![image-20230307125425364](image-20230307125425364.png)

- IP占用20字节

![image-20230307125456089](image-20230307125456089.png)

- TCP占用20字节

![image-20230307125541998](image-20230307125541998.png)

- HTTP占用156字节

| Ethernet        | IP               | TCP              | HTTP             |
| --------------- | ---------------- | ---------------- | ---------------- |
| 14B             | 20B              | 20B              | 156B             |
| Ethernet Header | Ethernet Payload | Ethernet Payload | Ethernet Payload |
|                 | IP Header        | IP Payload       | IP Payload       |

## 协议开销

![image-20230307131357336](image-20230307131357336.png)

有效开销为$156$B

协议开销：
$$
66 + 54 + 210 - 156 + 60 = 234B
$$
有效信息占比为
$$
156/390 = 40\%
$$
由此可知协议开销很大。



## 复用密钥

### *Which Ethernet header field is the demultiplexing key that tells it the next higher layer is IP?* 

![image-20230307132925472](image-20230307132925472.png)

Ethernet报头字段是 `Type` ，对应取值为 `0x0800`

### *Which IP header field is the demultiplexing key that tells it the next higher layer is TCP? What* 

![image-20230307133141265](image-20230307133141265.png)

IP包头字段是 `Protocol` ，对应取值为 `6`

# **Explore on your own**

## 不携带高层数据的短TCP数据包的作用

![image-20230307194625030](image-20230307194625030.png)

在三次握手协议中，需要客户端先发送TCP-服务器发回确认-客户端再次确认，这些数据包都是不含高层数据的短TCP。以上图中的TCP为例，为第三次握手。

## 服务器响应的数据包中第一个包和最后一个包有什么不同

1. 第一个包通常包含响应的 HTTP 头部，而最后一个包则包含 HTTP 实体的最后一部分或者完整的实体。
2. 第一个包和最后一个包的序列号和确认号（sequence number and acknowledgment number）也会不同，因为它们传输的是不同的数据。

## 底层加密如何实现

如果底层添加了加密，则底层将在从高层传递下来的消息中添加一个新的消息头（用于加密和解密），并将该消息传递到下一层。这意味着每个底层消息不再仅仅是一个被修改的高层消息，而是一个新的被加密的消息。这可能会导致下层消息的数量增加，因为一条高层消息可能需要多个被加密的消息来传输。这也使得协议分析和网络分析更加复杂。除此之外，密钥不应进行传输，而应与接收方协商防止加密失效。

## 下层增加压缩的变化

下层会将头附加到从高层传递下来的消息中，因此如果下层增加了压缩，该模型会发生变化。具体来说，在下层增加了压缩后，下层接收到来自高层的消息时，会将其压缩后附加头部，然后将消息和头部作为一个新的消息传递到下一层。在接收端，下层会解压消息并去除头部，然后将解压后的消息传递到上层。因此，压缩的添加会导致消息在传递过程中被改变，但整个分层模型的基本结构不会发生改变。

