<div class="cover" style="page-break-after:always;font-family:方正公文仿宋;width:100%;height:100%;border:none;margin: 0 auto;text-align:center;">
    <div style="width:60%;margin: 0 auto;height:0;padding-bottom:10%;">
        </br>
        <img src="D:\大三冲刺\计算机网络\实验\校名.png" alt="校名" style="width:100%;"/>
    </div>
    </br></br></br></br></br>
    <div style="width:60%;margin: 0 auto;height:0;padding-bottom:40%;">
        <img src="D:\大三冲刺\计算机网络\实验\校徽.png" alt="校徽" style="width:100%;"/>
	</div>
    </br></br></br></br></br></br></br></br>
    <span style="font-family:华文黑体Bold;text-align:center;font-size:20pt;margin: 10pt auto;line-height:30pt;">第6次实验：ARP</span>
    <p style="text-align:center;font-size:14pt;margin: 0 auto">实验报告 </p>
    </br>
    </br>
    <table style="border:none;text-align:center;width:72%;font-family:仿宋;font-size:14px; margin: 0 auto;">
    <tbody style="font-family:方正公文仿宋;font-size:12pt;">
    	<tr style="font-weight:normal;"> 
    		<td style="width:20%;text-align:right;">题　　目</td>
    		<td style="width:2%">：</td> 
    		<td style="width:40%;font-weight:normal;border-bottom: 1px solid;text-align:center;font-family:华文仿宋">ARP </td>     </tr><tr style="font-weight:normal;"> 
		<td style="width:20%;text-align:right;">授课教师</td>
		<td style="width:2%">：</td> 
		<td style="width:40%;font-weight:normal;border-bottom: 1px solid;text-align:center;font-family:华文仿宋">肖明忠 </td>     </tr>
	<tr style="font-weight:normal;"> 
		<td style="width:20%;text-align:right;">姓　　名</td>
		<td style="width:2%">：</td> 
		<td style="width:40%;font-weight:normal;border-bottom: 1px solid;text-align:center;font-family:华文仿宋"> 段欣然</td>     </tr>
	<tr style="font-weight:normal;"> 
		<td style="width:20%;text-align:right;">日　　期</td>
		<td style="width:2%">：</td> 
		<td style="width:40%;font-weight:normal;border-bottom: 1px solid;text-align:center;font-family:华文仿宋">2023.5.10</td>     </tr>
</tbody>              
</table></div>







<!-- 注释语句：导出PDF时会在这里分页 -->






<center><div style='height:2mm;'></div><div style="font-family:华文楷体;font-size:14pt;">段欣然，202011081033</div></center>
<center><span style="font-family:华文楷体;font-size:9pt;line-height:9mm">北京师范大学 人工智能学院</span>
</center>
<div>
<div style="width:52px;float:left; font-family:方正公文黑体;">目的：</div> 
<div style="overflow:hidden; font-family:华文楷体;">要看ARP（地址解析协议）如何工作。ARP是一个重要的胶合协议，它被用来 连接以太网和IP。它在你的课文的第5.6.4节中有所涉及。在做这个实验之前，先复习课文部分。
</div>
<div>
<div style="width:52px;float:left; font-family:方正公文黑体;">环境：</div> 
<div style="overflow:hidden; font-family:华文楷体;">WireShark；arp；ifconfig/ipconfig；route/netstat；Browser </div>
</div>




<hr>													
<center><b><font size=6>实验报告正文</font></b></center>



# 实验过程

## ipconfig查看Mac地址

`ipconfig /all`

![image-20230624102625056](D:\大三冲刺\计算机网络\实验\lab6\image-20230624102625056.png)

## netstat找到默认网关ip地址

`netstat -r`

![image-20230624102809916](D:\大三冲刺\计算机网络\实验\lab6\image-20230624102809916.png)

## WireShark捕获数据包

由于本机使用`arp -d`提示参数错误，与系统设置有关，在本实验中使用官网提供的捕获好的数据包

其中

Ethernet address of computer == 00:25:64:d5:10:8b

IP address of default gateway == 128.208.2.100

![image-20230624103456125](D:\大三冲刺\计算机网络\实验\lab6\image-20230624103456125.png)

## 过滤协议，找出发送方或接收方是自己计算机的包

`eth.addr == 00:25:64:d5:10:8b`

![image-20230624103638547](D:\大三冲刺\计算机网络\实验\lab6\image-20230624103638547.png)

## 查看ARP请求包

![image-20230624104404076](D:\大三冲刺\计算机网络\实验\lab6\image-20230624104404076.png)

请求信息将以“who”开始，如上图，并且后面的地址为默认网关地址。

各字段含义如下：

| Hardware type: Ethernet (1) Protocol type: IPv4 (ox0800) | 指明硬件是类型和协议使用的分别是以太网和iPv4，便于ARP将IP地址转为MAC地址。 |
| -------------------------------------------------------- | ------------------------------------------------------------ |
| Hardware size:                                           | 6                                                            |
| Protocol size: 4                                         | 表示以太网和IP地址的字节数                                   |
| Opcode：request (1)                                      | 说明是请求包                                                 |
| sender MAC address:                                      | 发生方的MAC地址                                              |
| sender IP address:                                       | 发送方IP地址                                                 |
| Target MAC address:全0                                   | 目标MAC地址                                                  |
| Target IP address:                                       | 目标IP地址                                                   |

此时还不知道目标的MAC地址所以为0

## 查看应答包的内容

其info一般为：ip地址 is at mac地址

![image-20230624104525323](D:\大三冲刺\计算机网络\实验\lab6\image-20230624104525323.png)

Opcode：reply (2) 说明是应答包

由于两个计算机已经提供的他们的MAC地址，此时字段应该全部填写

![image-20230624105508145](D:\大三冲刺\计算机网络\实验\lab6\image-20230624105508145.png)

# 实验结果

## 用来标识请求包/应答包的操作码是什么

Opcode字段：request (1) reply (2)

## 一个请求/应答的ARP头有多大

28 Byte

## 对未知的目标MAC地址的请求中携带了什么值

全0

## 说明ARP是上层协议的“Ethernet Type”值是多少

Type: ARP (0x0806)

## ARP是否应答广播

ARP应答通常是单播，仅仅发送给请求方

# 实验反思

通过本次实验，我成功地学习了ARP（地址解析协议）的工作原理。ARP是连接以太网和IP的重要协议，它在计算机网络课程的第5.6.4节中有所介绍。在实验中，我使用了WireShark、arp、ifconfig/ipconfig、route/netstat和浏览器等工具进行实验。我按照以下步骤进行了实验：

1. 使用ipconfig命令查看本机的MAC地址。
2. 使用netstat命令找到默认网关的IP地址。
3. 使用WireShark捕获数据包，其中包含了本机的MAC地址和默认网关的IP地址。
4. 过滤数据包，筛选出发送方或接收方是本机计算机的包。
5. 查看ARP请求包，其中包含了请求方的MAC地址和IP地址。
6. 查看ARP应答包，其中包含了目标方的MAC地址和IP地址。

通过实验，我得出了以下结论：

1. ARP请求包和应答包的操作码分别为请求（1）和应答（2）。
2. 一个ARP头的大小为28字节。
3. 对于未知目标MAC地址的请求，其携带的值为全0。
4. ARP作为上层协议的“Ethernet Type”值为0x0806。
5. ARP应答通常是单播，只发送给请求方。

通过这次实验，我加深了对ARP协议的理解，掌握了ARP的工作原理和相关字段的含义。这对我进一步学习和研究计算机网络具有重要的意义。
