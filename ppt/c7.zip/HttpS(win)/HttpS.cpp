//HttpS.cpp : Defines the entry point for the application. use VC 6.0
//
//=========================================================================
//�¼��������������γ̣�Ӧ�ò�Э�飬��򵥵�Http Server�˳���

//=========================================================================

#include "stdafx.h"		//VC 6.0
//VC 6.0   add  WSOCK32.LIB in Project -> Settings... ->  Link
#include <winsock.h>
#include <stdlib.h>
#include <stdio.h>
//--------------------------------------------------------------
// Global Variables:
HINSTANCE hInst;						// current instance

LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
//--------------------------------------------------------------
int APIENTRY WinMain(HINSTANCE hI,HINSTANCE hP,LPSTR lp,int nC)
{
	MSG msg;
	HWND hWnd;
	hInst = hI; // Store instance handle in our global variable
	WNDCLASS wc;

	memset(&wc,0,sizeof(WNDCLASS));

	wc.lpfnWndProc	= (WNDPROC)WndProc;
	wc.hInstance		= hI;
	wc.hIcon			= LoadIcon(NULL, IDI_APPLICATION);
	wc.hbrBackground	= (HBRUSH)COLOR_WINDOW;
	wc.lpszClassName	= "W1";
	RegisterClass(&wc);

	hWnd=CreateWindowEx(WS_EX_TOPMOST,"W1","HTTP server",
		WS_OVERLAPPEDWINDOW|WS_SYSMENU,
		350,80,300,300,
		NULL, NULL, hI, NULL);
   	if (!hWnd)   return FALSE;

   	ShowWindow(hWnd, nC);
	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return msg.wParam;
}
//---------------------------------------------------------------------------
//��ť
HWND CreateButton(char *Titel,int x0,int y0,int w,int h,int ID,HWND hW,HINSTANCE hInst)
{
	return CreateWindowEx(WS_EX_PALETTEWINDOW,"BUTTON",Titel,
		WS_VISIBLE | WS_CHILD ,
		x0,y0,w,h, hW,(HMENU)ID,hInst,NULL);
}
//---------------------------------------------------------------------------
//���б༭��
HWND CreateEdit(char *Titel,int x0,int y0,int w,int h,int ID,HWND hW,HINSTANCE hInst)
{
	return CreateWindowEx(WS_EX_CLIENTEDGE,"EDIT",Titel,
		WS_VISIBLE | WS_CHILD |
		    ES_LEFT | ES_MULTILINE | WS_HSCROLL ,
		x0,y0,w,h, hW,
		(HMENU)ID,hInst,NULL);
}
//---------------------------------------------------------------------------
//�����ı���
HWND CreateMemo(char *Titel,int x0,int y0,int w,int h,int ID,HWND hW,HINSTANCE hInst)
{
	return CreateWindowEx(WS_EX_CLIENTEDGE,"EDIT",Titel,
		WS_VISIBLE | WS_CHILD |
		    ES_LEFT | ES_MULTILINE |ES_READONLY|
		    WS_HSCROLL | WS_VSCROLL,
		x0,y0,w,h,
		hW,(HMENU)ID,hInst,NULL);
}
//---------------------------------------------------------------------------
//���ӿؼ��ı�
void Puts(HWND hW,int ID_EDIT,char *str)
{
	char b[80000];
	GetDlgItemText(hW,ID_EDIT,b,sizeof(b));
	strcat(b,"\r\n");
	strcat(b,str);
	SetDlgItemText(hW,ID_EDIT,(LPSTR) b);
	SendMessage(GetDlgItem(hW,ID_EDIT),WM_VSCROLL,SB_THUMBPOSITION+1000*0x10000,0);
}
//---------------------------------------------------------------------------
//��ť
#define BUTTON1 501
//---------------------------------------------------------------------------
//���б༭��
#define EDIT1 601
//---------------------------------------------------------------------------
//�����ı���
#define MEMO1 701
//---------------------------------------------------------------------------
void Rec(char *p)	//��Client��������Ϣ��¼���ļ�Rec.txt��
{
	FILE *fp=fopen("Rec.txt","a+");
	fprintf(fp,"%s\n",p);
	fclose(fp);
}
//---------------------------------------------------------------------------
WSADATA ws;
SOCKET Ss,Cs;
struct sockaddr_in SA,CA;
char aa[100000];
char bb[2000];
int d;
int ProcessGET(char *uri);
int ProcessPOST(char *uri,char *str);
int ProcessCGI(char *uri);
long GetFile(char *fn);	//���ļ�
long l;
//---------------------------------------------------------------------------
//��Ϣ����
LRESULT CALLBACK WndProc(HWND hW, UINT msg, WPARAM wP, LPARAM lP)
{
	switch (msg)
	{
	case WM_DESTROY:			//�رճ��򴥷��¼�
		WSAAsyncSelect(Ss, hW, 0, 0);	//��Windowsע��Socket�����¼�
		closesocket(Ss);				//�ͷ�����
		WSACleanup( );					//ж�ض�̬���ӿ�WinSock DLL
		PostQuitMessage(0);
		break;
	case WM_CREATE:				//�����ʼ�������¼�
		WSAStartup(0x0101,&ws);			//װ�ض�̬���ӿ�WinSock DLL
		CreateButton("Start",10,2,50,20,BUTTON1,hW,hInst);
		CreateEdit("127.0.0.1",70,2,220,20,EDIT1,hW,hInst);
		CreateMemo("Info.",	0,25,290,250,MEMO1,hW,hInst);	//������Ϣ��ʾ����
		SetFocus(GetDlgItem(hW,BUTTON1));
		break;
	case WM_USER+1:						//Socket�����¼�
		switch(LOWORD(lP))
		{
		case FD_ACCEPT:					//Client�Ľ�����������
			d=sizeof(CA);
			Cs=accept(Ss,(struct sockaddr *) &CA,&d);//����Chat Client����������
			break;
		case FD_READ:					//�յ�Client��Ϣ
			d=recv(wP,bb,2000,0);//wP=Cs//�����ջ�����

			bb[d]=0;
//			Rec(bb);		//��Client��������Ϣ��¼���ļ�Rec.txt��
			Puts(hW,MEMO1,bb);
			
			char method[11],uri[111],ver[11];
			sscanf(bb,"%s %s %s",method,uri,ver);	//�����зֽ�
			if(!stricmp(method,"GET")) 
				ProcessGET(uri);
			if(!stricmp(method,"POST")) 
				ProcessPOST(uri,bb);

			if(l) 
			  send(wP,aa,l,0);	//������Ϣ���ļ����ݣ�
			closesocket(wP);	//�ͷ�����
			break;
		}
	case WM_COMMAND:
		switch(wP)
		{
		case BUTTON1:
			GetDlgItemText(hW,EDIT1,aa,sizeof(aa));
			Ss=socket(AF_INET, SOCK_STREAM,0);	//����TCP�׽���Socket
			SA.sin_family=AF_INET;
			SA.sin_port = htons(80);			//�������˿ڡ�
			SA.sin_addr.s_addr =inet_addr(aa);	//��������ַ��

			bind(Ss,(struct sockaddr *) &SA,sizeof(SA));	
			WSAAsyncSelect(Ss,hW,WM_USER+1,FD_ACCEPT|FD_READ);	//��Windowsע��Socket�����¼�
			listen(Ss,100);						//�������ӻ�������100������
			EnableWindow(GetDlgItem(hW,BUTTON1),FALSE);
			EnableWindow(GetDlgItem(hW,EDIT1),FALSE);
			break;
		}
		break;
	}
	return DefWindowProc(hW,msg,wP,lP);
}
//---------------------------------------------------------------------------
long GetFile(char *fn)	//���ļ�
{
long len;
	FILE *fp=fopen(fn,"rb");
	if(fp==NULL) return 0L;
	fseek(fp,0L,2);
	len = ftell(fp);
	fseek(fp,0L,0);
	fread(aa, 1,len,fp);
	fclose(fp);
	return len;
}
//---------------------------------------------------------------------------
int ProcessGET(char *uri)
{
char *ps;
	if(strchr(uri,'?')!=NULL)
	{
		ProcessCGI(uri);
		return 0;
	}
	ps = strchr(uri,'/');
	ps++;
	if(!strlen(ps))
		l=GetFile("Index.htm");
	else
	    l=GetFile(ps);
	if(!l)
	{
		ps = strchr(ps,'.');
		ps++;
		if(!stricmp(ps,"htm")) l=GetFile("Error401.htm");
		if(!stricmp(ps,"html")) l=GetFile("Error401.htm");
		return 1;
	}
	return 0;
}
//---------------------------------------------------------------------------
int ProcessPOST(char *uri,char *str)
{
char *ps;
char *Str1="<html>\n<head>\n<title>CGI-Test</title>\n</head>\n";
char *Str2="<body>\n<p>POST������</p>\n<p>������Ĳ�ѯֵ���¡�</p>\n";
char *Str3="<p><a href=\"CGITest.htm\">����</a><p>\n";
char *Str4="</body>\n</html>\n";

	ps = strstr(str,"\xd\xa\xd\xa");

	strcpy(aa,Str1);
	strcat(aa,Str2);
	strcat(aa,ps+4);
	strcat(aa,Str3);
	strcat(aa,Str4);
	l=strlen(aa);

	return 0;
}
//---------------------------------------------------------------------------
int ProcessCGI(char *uri)
{
char *ps;
char *Str1="<html>\n<head>\n<title>CGI-Test</title>\n</head>\n";
char *Str2="<body>\n<p>GET������</p>\n<p>������Ĳ�ѯֵ���¡�</p>\n";
char *Str3="<p><a href=\"CGITest.htm\">����</a><p>\n";
char *Str4="</body>\n</html>\n";
	strcpy(aa,Str1);
	strcat(aa,Str2);
	ps = strchr(uri,'?');
	ps++;
	strcat(aa,ps);
	strcat(aa,Str3);
	strcat(aa,Str4);
	l=strlen(aa);
	return 0;
}
//---------------------------------------------------------------------------

